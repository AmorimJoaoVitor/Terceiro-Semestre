import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Formatter;
import java.util.FormatterClosedException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class AppBebidas {
    public static void gravaArquivoCsv (ListaObj<Bebida> lista, String nomeArquivo) {
        FileWriter arquivo = null;
        Formatter saida = null;
        Boolean err = false;

        nomeArquivo += ".csv";

        try {
            arquivo = new FileWriter(nomeArquivo, true);
            saida = new Formatter(arquivo);
        }
        catch (IOException erro) {
            System.out.println("Erro ao abrir o arquivo");
            System.exit(1);
        }

        // Bloco try-catch para gravar no arquivo
        try {
            // Percorro a lista de cachorros
            for (int i = 0; i < lista.getTamanho(); i++) {
                // Obtenho um objeto dog da lista por vez (o do índice i)
                Bebida bebida = lista.getElemento(i);
                // Gravo os dados desse objeto no arquivo
                // Separando cada campo por um ;
                saida.format("%d;%s;%.2f;%s;%s;%s;%.2f\n",bebida.getId(), bebida.getNomeBebida(),
                        bebida.getTeorAlcolico(), bebida.getTipo(), bebida.getFabricacao(), bebida.getValidade(),
                        bebida.getPreco());
            }
        }
        catch (FormatterClosedException erro) {
            System.out.println("Erro ao gravar arquivo");
            err = true;
        }
        finally {
            saida.close();
            try {
                arquivo.close();
            }
            catch (IOException erro) {
                System.out.println("Erro ao fechar o arquivo");
                err = true;
            }
            if (err) {
                System.exit(1);
            }
        }
    }

    public static void leExibeArquivoCsv(String nomeArquivo){
        FileReader arquivo = null;
        Scanner entrada = null;
        Boolean err = false;
        nomeArquivo = nomeArquivo + ".csv";

        try {
            arquivo = new FileReader(nomeArquivo);
            entrada = new Scanner(arquivo).useDelimiter(";|\\n");
        }
        catch (FileNotFoundException erro) {
            System.out.println("Arquivo não encontrado");
            System.exit(1);
        }

        try {
            System.out.printf("%-6s %-14s %-7s %-10s %-9s %8s %9s\n", "ID", "NOME BEBIDA", "TEOR ALC", "TIPO", "FABRICACAO", "VALIDADE",
                    "PRECO");

            while(entrada.hasNext()) {
                int id = entrada.nextInt();
                String nomeBebida = entrada.next();
                Double teor = entrada.nextDouble();
                String tipo = entrada.next();
                String fabricacao = entrada.next();
                String validade = entrada.next();
                Double preco = entrada.nextDouble();
                System.out.printf("%06d %-14s %-7d %12s %9s %7s %18.2f\n", id, nomeBebida, teor, tipo, fabricacao, validade,
                        preco);
            }
        }
        catch (NoSuchElementException erro) {
            System.out.println("Arquivo com problemas");
            err = true;
        }
        catch (IllegalStateException erro) {
            System.out.println("Erro na leitura do arquivo");
            err = true;
        }
        finally {
            entrada.close();
            try {
                arquivo.close();
            }
            catch (IOException erro) {
                System.out.println("Erro ao fechar arquivo");
                err = true;
            }
            if (err) {
                System.exit(1);
            }
        }
    }

    public static void main(String[] args) {
        ListaObj list = new ListaObj(7);
        Scanner input = new Scanner(System.in);
        int escolha = 0;
        Boolean fim = false;
        String nomeBebida, tipo, validade, fabricacao, condicao;
        Double teorAlc, preco;
        int id, escolhaBebida;

        while (!fim){
            System.out.println("Escolha uma ação");

            System.out.println("1 Cadastrar bebida" +
                    "\n2 Exibir lista de bebidas cadastradas" +
                    "\n3 Busca bebida pelo id" +
                    "\n4 Ler e exibir o arquivo CSV" +
                    "\n5 Criar um arquivo CSV com conteúdo da lista" +
                    "\n6 Fim");
            escolha = input.nextInt();
            switch (escolha){
                case 1:
                    System.out.println("Entre com o id da bebida:");
                    id = input.nextInt();
                    System.out.println("Entre com o nome da bebida:");
                    nomeBebida = input.next();
                    System.out.println("Entre com o tipo da bebida:");
                    tipo = input.next();
                    System.out.println("Entre com a data de fabricação (dd-mm-aaaa)");
                    fabricacao = input.next();
                    System.out.println("Entre com a data de validade (dd-mm-aaaa)");
                    validade = input.next();
                    System.out.println("Insira o teor alcólico da bebida (%)");
                    teorAlc = input.nextDouble();
                    System.out.println("Cadastre o preço da bebida (R$)");
                    preco = input.nextDouble();

                    Bebida novaBebida = new Bebida(id,nomeBebida,teorAlc,tipo,fabricacao,validade,preco);

                    list.adiciona(novaBebida);
                    break;
                case 2:
                    list.exibe();
                    break;
                case 3:
                    Boolean existente = false;

                    if (list.getTamanho() == 0){
                        System.out.println("Não há nada para exibir");
                    }
                    System.out.println("Pesquise pelo id da bebida cadastrada");
                    escolhaBebida = input.nextInt();

                    for (int i = 0; i < list.getTamanho(); i++){
                        Bebida b = (Bebida) list.getElemento(i);

                        if (b.getId().equals(escolhaBebida)){
                            System.out.println(b);
                            existente = true;
                        }
                    }
                    condicao = (!existente) ? "Não existe nenhum ítem com este id na lista de bebidas" : "Existe";
                    System.out.println(condicao);
                    break;
                    case 4:
                    leExibeArquivoCsv("lista-bebidas-cadastradas");
                    break;
                case 5:
                    if (list.getTamanho() == 0) {
                        System.out.println("Lista está vazia, não é possível gerar arquivo CSV");
                    }
                    else {
                        gravaArquivoCsv(list,"lista-bebidas");
                    }
                    break;
                case 6:
                    fim = true;
                    break;
                default:
                    System.out.println("Inválido");
                    break;
            }
        }

    }
}
