import java.time.LocalDate;

public class Bebida {
    private Integer id;
    private String nomeBebida;
    private Double teorAlcolico;
    private String tipo;
    private String fabricacao;
    private String validade;
    private Double preco;

    public Bebida(Integer id, String nomeBebida, Double teorAlcolico, String tipo, String fabricacao, String validade, Double preco) {
        this.id = id;
        this.nomeBebida = nomeBebida;
        this.teorAlcolico = teorAlcolico;
        this.tipo = tipo;
        this.fabricacao = fabricacao;
        this.validade = validade;
        this.preco = preco;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNomeBebida() {
        return nomeBebida;
    }

    public void setNomeBebida(String nomeBebida) {
        this.nomeBebida = nomeBebida;
    }

    public Double getTeorAlcolico() {
        return teorAlcolico;
    }

    public void setTeorAlcolico(Double teorAlcolico) {
        this.teorAlcolico = teorAlcolico;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getFabricacao() {
        return fabricacao;
    }

    public void setFabricacao(String fabricacao) {
        this.fabricacao = fabricacao;
    }

    public String getValidade() {
        return validade;
    }

    public void setValidade(String validade) {
        this.validade = validade;
    }

    public Double getPreco() {
        return preco;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }

    @Override
    public String toString() {
        return "Bebida{" +
                "id=" + id +
                ", nomeBebida='" + nomeBebida + '\'' +
                ", teorAlcolico=" + teorAlcolico +
                ", tipo='" + tipo + '\'' +
                ", fabricacao=" + fabricacao +
                ", validade=" + validade +
                ", preco='" + preco + '\'' +
                '}';
    }
}