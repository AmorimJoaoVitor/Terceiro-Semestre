public class ListaEstatica {
    int[] vetor;
    int nroElem;
    int contVet = 0;
    public ListaEstatica(int tam) {
        this.vetor = new int[tam];
        this.nroElem = 0;
    }

    public Boolean adiciona(int element) {
        if (nroElem == vetor.length){
            return false;
        }
        else {
            vetor[nroElem++] = element;
            return true;
        }
    }

    public void exibe(){
        for (int i = 0; i < vetor.length;i++){
            System.out.println(vetor[i]);
        }
    }

    public void busca(int element){
        for (int i = 0; i < vetor.length; i++){
            if (vetor[i] == element){
                System.out.println(vetor[i]);
            }
        }
    }

}
